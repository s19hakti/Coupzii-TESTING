#!/bin/bash
# Coupzii Deployment Script

echo "🚀 Starting Coupzii deployment..."

# Copy environment file
if [ ! -f backend/.env ]; then
    echo "📝 Creating .env file from template..."
    cp backend/.env.example backend/.env
    echo "⚠️  Please edit backend/.env with your actual credentials!"
    exit 1
fi

# Build and start containers
echo "🐳 Building Docker containers..."
cd docker
docker-compose up --build -d

echo "⏳ Waiting for services to start..."
sleep 10

# Check if services are running
if docker-compose ps | grep -q "Up"; then
    echo "✅ Services started successfully!"
    echo "🌐 Backend running on http://localhost:3000"
    echo "📊 PostgreSQL running on localhost:5432"
    echo "🔴 Redis running on localhost:6379"
else
    echo "❌ Failed to start services"
    docker-compose logs
    exit 1
fi

echo "🎉 Deployment complete!"
echo "📝 View logs: cd docker && docker-compose logs -f"
