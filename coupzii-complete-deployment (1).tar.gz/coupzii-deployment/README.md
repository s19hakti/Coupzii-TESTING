# 🎫 Coupzii - Complete Deployment Package

## 📦 Package Contents

```
coupzii-deployment/
├── backend/              # Node.js backend server
│   ├── server.js        # Main server file
│   ├── package.json     # Dependencies
│   ├── .env.example     # Environment template
│   ├── config/          # Database & Redis config
│   ├── routes/          # API routes
│   ├── middleware/      # Auth & validation
│   ├── services/        # External services
│   └── utils/           # Helper functions
├── frontend/            # Website files
│   └── index.html       # Main website
├── database/            # Database setup
│   └── schema.sql       # PostgreSQL schema
├── docker/              # Docker configuration
│   ├── Dockerfile       # Backend container
│   └── docker-compose.yml  # All services
└── scripts/             # Deployment scripts
    └── deploy.sh        # One-click deploy
```

## 🚀 Quick Start (< 5 minutes)

### Prerequisites
- Docker & Docker Compose installed
- Node.js 18+ (for local development)
- Git (optional)

### Option 1: Docker Deployment (Recommended)

```bash
# 1. Navigate to deployment folder
cd coupzii-deployment

# 2. Configure environment
cp backend/.env.example backend/.env
# Edit backend/.env with your settings

# 3. Deploy everything
./scripts/deploy.sh
```

That's it! Your backend is now running on http://localhost:3000

### Option 2: Manual Deployment

```bash
# 1. Start database
cd docker
docker-compose up -d postgres redis

# 2. Install dependencies
cd ../backend
npm install

# 3. Configure environment
cp .env.example .env
# Edit .env file

# 4. Start server
npm start
```

## 🔧 Configuration

### Essential Environment Variables

Edit `backend/.env`:

```env
# Database
DATABASE_URL=postgresql://admin:password@localhost:5432/coupzii

# JWT
JWT_SECRET=change-this-to-random-string

# Payment (Optional for testing)
RAZORPAY_KEY_ID=your_key
RAZORPAY_KEY_SECRET=your_secret

# AI Assistant (Optional)
OPENAI_API_KEY=sk-your-key
```

## 📡 API Endpoints

### Authentication
- `POST /api/auth/register/user` - Register user
- `POST /api/auth/register/brand` - Register brand  
- `POST /api/auth/login` - Login
- `POST /api/auth/verify-otp` - Verify OTP

### User
- `GET /api/user/wallet` - Get wallet coupons
- `POST /api/user/wallet/add` - Add coupon
- `GET /api/user/marketplace` - Browse marketplace
- `POST /api/user/marketplace/list` - List coupon for sale

### Brand
- `POST /api/brand/coupon/create` - Create coupon
- `POST /api/brand/coupon/bulk-upload` - Bulk upload
- `GET /api/brand/coupons` - Get all coupons
- `GET /api/brand/analytics` - Get analytics

### AI Assistant
- `POST /api/ai/chat` - Chat with AI

### Payment
- `POST /api/payment/create-order` - Create payment
- `POST /api/payment/verify` - Verify payment

## 🌐 Frontend Setup

1. Open `frontend/index.html` in a browser
2. Or serve with:
```bash
cd frontend
python3 -m http.server 8080
# Visit http://localhost:8080
```

## 🐳 Docker Commands

```bash
# Start all services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down

# Restart services
docker-compose restart

# View running containers
docker-compose ps
```

## 🗄️ Database Management

### Connect to PostgreSQL
```bash
docker exec -it docker_postgres_1 psql -U admin -d coupzii
```

### Common SQL Commands
```sql
-- View all tables
\dt

-- View users
SELECT * FROM users;

-- View coupons
SELECT * FROM coupons;

-- Reset database
DROP SCHEMA public CASCADE;
CREATE SCHEMA public;
```

## 🔐 Production Deployment

### AWS EC2 Deployment

1. **Launch EC2 Instance**
   - Ubuntu 22.04 LTS
   - t3.medium or larger
   - Open ports: 22, 80, 443, 3000

2. **Install Docker**
```bash
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker ubuntu
```

3. **Deploy Application**
```bash
git clone your-repo
cd coupzii-deployment
./scripts/deploy.sh
```

4. **Setup Nginx (Optional)**
```bash
sudo apt install nginx
sudo nano /etc/nginx/sites-available/coupzii

# Add:
server {
    listen 80;
    server_name your-domain.com;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
    }
}
```

### Heroku Deployment

```bash
# Install Heroku CLI
# Then:
heroku login
heroku create coupzii
heroku addons:create heroku-postgresql:hobby-dev
heroku addons:create heroku-redis:hobby-dev
git push heroku main
```

### Vercel/Netlify (Frontend Only)

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy frontend
cd frontend
vercel
```

## 🔍 Testing the API

### Using curl
```bash
# Register user
curl -X POST http://localhost:3000/api/auth/register/user \
  -H "Content-Type: application/json" \
  -d '{"email":"test@test.com","password":"password123","full_name":"Test User"}'

# Login
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@test.com","password":"password123","login_type":"user"}'
```

### Using Postman
1. Import the API collection (if provided)
2. Set base URL: http://localhost:3000
3. Test endpoints

## 📊 Monitoring

### View Logs
```bash
# Backend logs
docker-compose logs -f backend

# Database logs
docker-compose logs -f postgres

# All logs
docker-compose logs -f
```

### Health Check
```bash
curl http://localhost:3000/health
```

## 🐛 Troubleshooting

### Port Already in Use
```bash
# Find process using port 3000
lsof -i :3000
kill -9 <PID>
```

### Database Connection Error
```bash
# Check if PostgreSQL is running
docker-compose ps
docker-compose logs postgres

# Restart database
docker-compose restart postgres
```

### Redis Connection Error
```bash
# Check Redis
docker-compose logs redis
docker-compose restart redis
```

## 📈 Scaling

### Horizontal Scaling
```bash
# Scale backend instances
docker-compose up -d --scale backend=3
```

### Production Database
- Migrate to managed service (AWS RDS, Heroku Postgres)
- Update DATABASE_URL in .env

## 🔒 Security Checklist

- [ ] Change all default passwords
- [ ] Generate new JWT_SECRET
- [ ] Enable HTTPS
- [ ] Configure CORS properly
- [ ] Set up firewall rules
- [ ] Enable rate limiting
- [ ] Regular backups
- [ ] Update dependencies

## 💰 Cost Estimates

### Free Tier (Testing)
- Heroku Hobby: $0/month
- Vercel: $0/month
- Supabase: $0/month
**Total: $0/month**

### Production
- AWS EC2 t3.medium: $30/month
- AWS RDS: $15/month
- S3 Storage: $5/month
- CloudFlare: $0/month
**Total: ~$50/month**

## 📞 Support

- GitHub Issues: [Create Issue]
- Email: support@coupzii.com
- Documentation: https://docs.coupzii.com

## 📄 License

MIT License - See LICENSE file

---

**Made with ❤️ by Coupzii Team**

🎉 **Happy Deploying!**
