# 🚀 Coupzii Complete Deployment Guide

## ⚡ FASTEST DEPLOYMENT (5 Minutes)

### Step 1: Install Docker (if not installed)

**Mac:**
```bash
brew install --cask docker
```

**Windows:**
Download from https://www.docker.com/products/docker-desktop

**Linux (Ubuntu):**
```bash
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
```

### Step 2: Configure Environment

```bash
cd coupzii-deployment
cp backend/.env.example backend/.env
```

**Edit backend/.env** - Minimum required:
```env
JWT_SECRET=your-random-secret-key-here
DATABASE_URL=postgresql://admin:coupzii2024@postgres:5432/coupzii
REDIS_URL=redis://redis:6379
```

### Step 3: Deploy

```bash
chmod +x scripts/deploy.sh
./scripts/deploy.sh
```

**Done!** 🎉
- Backend: http://localhost:3000
- Frontend: Open `frontend/index.html` in browser

---

## 🌐 FREE HOSTING OPTIONS

### Option 1: Render.com (Easiest)

1. Go to https://render.com
2. Create New → Web Service
3. Connect GitHub repo
4. Build Command: `cd backend && npm install`
5. Start Command: `cd backend && node server.js`
6. Add environment variables
7. Create PostgreSQL database (free tier)
8. Deploy!

**Free Tier:** 750 hours/month

### Option 2: Railway.app

1. Go to https://railway.app
2. New Project → Deploy from GitHub
3. Add PostgreSQL plugin
4. Add Redis plugin
5. Deploy

**Free Tier:** $5 credit/month

### Option 3: Fly.io

```bash
# Install flyctl
curl -L https://fly.io/install.sh | sh

# Deploy
cd backend
fly launch
fly deploy
```

**Free Tier:** 3 shared VMs

---

## 💻 PRODUCTION DEPLOYMENT

### AWS EC2 (Full Control)

#### 1. Launch Instance
- Ubuntu 22.04
- t3.medium (2 CPU, 4GB RAM)
- Security Group: Allow 22, 80, 443

#### 2. Connect & Setup
```bash
ssh -i your-key.pem ubuntu@your-instance-ip

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Clone repository
git clone https://github.com/your-repo/coupzii
cd coupzii/coupzii-deployment

# Deploy
./scripts/deploy.sh
```

#### 3. Setup Domain (Optional)
```bash
# Install Nginx
sudo apt update
sudo apt install nginx certbot python3-certbot-nginx

# Configure Nginx
sudo nano /etc/nginx/sites-available/coupzii
```

Add:
```nginx
server {
    listen 80;
    server_name coupzii.com www.coupzii.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/coupzii /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx

# Get SSL
sudo certbot --nginx -d coupzii.com -d www.coupzii.com
```

### Google Cloud Platform

```bash
# Install gcloud CLI
curl https://sdk.cloud.google.com | bash

# Initialize
gcloud init

# Create instance
gcloud compute instances create coupzii \
    --image-family=ubuntu-2204-lts \
    --image-project=ubuntu-os-cloud \
    --machine-type=e2-medium \
    --zone=us-central1-a

# SSH and deploy
gcloud compute ssh coupzii
```

---

## 🔑 ENVIRONMENT VARIABLES EXPLAINED

### Required (Minimum)
```env
JWT_SECRET=random-string-min-32-chars
DATABASE_URL=postgresql://user:pass@host:5432/dbname
```

### Recommended
```env
# Redis (for caching)
REDIS_URL=redis://localhost:6379

# Email (for OTP)
SMTP_HOST=smtp.gmail.com
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password

# SMS (for OTP)
TWILIO_ACCOUNT_SID=ACxxxx
TWILIO_AUTH_TOKEN=token
TWILIO_PHONE_NUMBER=+1234567890
```

### Optional (Add Later)
```env
# Payment
RAZORPAY_KEY_ID=rzp_test_xxxx
RAZORPAY_KEY_SECRET=secret

# AI Assistant
OPENAI_API_KEY=sk-xxxx

# File Storage
AWS_ACCESS_KEY_ID=AKIA....
AWS_SECRET_ACCESS_KEY=secret
S3_BUCKET_NAME=coupzii-uploads
```

---

## 🧪 TESTING

### 1. Backend Health Check
```bash
curl http://localhost:3000/health
```

### 2. Register Test User
```bash
curl -X POST http://localhost:3000/api/auth/register/user \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@test.com",
    "password": "Test@123",
    "full_name": "Test User",
    "phone": "+911234567890"
  }'
```

### 3. Login
```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@test.com",
    "password": "Test@123",
    "login_type": "user"
  }'
```

---

## 📊 MONITORING

### View Logs
```bash
# All logs
docker-compose logs -f

# Backend only
docker-compose logs -f backend

# Last 100 lines
docker-compose logs --tail=100
```

### Database Access
```bash
# Connect to PostgreSQL
docker exec -it docker_postgres_1 psql -U admin -d coupzii

# Check tables
\dt

# View users
SELECT * FROM users;
```

---

## 🐛 COMMON ISSUES

### Issue: Port 3000 already in use
```bash
# Find and kill process
lsof -i :3000
kill -9 <PID>

# Or use different port
PORT=3001 npm start
```

### Issue: Database connection failed
```bash
# Check PostgreSQL status
docker-compose ps postgres

# Restart database
docker-compose restart postgres

# Check logs
docker-compose logs postgres
```

### Issue: Module not found
```bash
# Reinstall dependencies
cd backend
rm -rf node_modules package-lock.json
npm install
```

---

## 📈 SCALING

### Database Optimization
```sql
-- Add indexes
CREATE INDEX idx_coupons_valid ON coupons(valid_until) WHERE is_active = true;
CREATE INDEX idx_wallet_user_active ON user_wallet(user_id) WHERE is_used = false;

-- Vacuum regularly
VACUUM ANALYZE;
```

### Redis Caching
Already configured! The backend caches:
- Marketplace listings (2 min)
- User wallet (5 min)
- Brand analytics (5 min)

### Load Balancing
```bash
# Scale backend instances
docker-compose up -d --scale backend=3
```

---

## 💰 COST BREAKDOWN

### Free Tier
- Render.com: Free (with limits)
- Railway.app: $5 credit/month
- Fly.io: Free tier available
**Total: $0-5/month**

### Small Business
- DigitalOcean Droplet: $12/month
- Managed Database: $15/month
- CloudFlare CDN: Free
**Total: $27/month**

### Production
- AWS EC2 t3.medium: $35/month
- AWS RDS db.t3.small: $25/month
- S3 Storage: $5/month
- CloudFront CDN: $5/month
**Total: $70/month**

---

## ✅ PRE-LAUNCH CHECKLIST

- [ ] Database configured
- [ ] Environment variables set
- [ ] SSL certificate installed
- [ ] Payment gateway tested
- [ ] Email service working
- [ ] Backup system configured
- [ ] Monitoring setup
- [ ] Rate limiting enabled
- [ ] CORS configured
- [ ] Frontend connected to backend

---

## 🎯 NEXT STEPS

1. **Test Everything**
   - Create user account
   - Add test coupons
   - Test payment flow
   - Check email/SMS

2. **Set Up Monitoring**
   - Add Sentry for errors
   - Set up uptime monitoring
   - Configure alerts

3. **Launch Marketing**
   - Social media
   - Landing page
   - Google Ads

4. **Scale as Needed**
   - Add more servers
   - Optimize database
   - Enable CDN

---

## 📞 NEED HELP?

- **Documentation:** Check README.md
- **Issues:** Create GitHub issue
- **Email:** support@coupzii.com

---

**Good Luck! 🚀**
