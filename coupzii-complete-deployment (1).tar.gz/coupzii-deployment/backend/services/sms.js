const twilio = require('twilio');

const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);

async function sendOTP(phone, otp) {
  try {
    if (!process.env.TWILIO_ACCOUNT_SID) {
      console.log(`Mock OTP for ${phone}: ${otp}`);
      return true;
    }
    
    await client.messages.create({
      body: `Your Coupzii verification code is: ${otp}`,
      from: process.env.TWILIO_PHONE_NUMBER,
      to: phone
    });
    return true;
  } catch (error) {
    console.error('SMS error:', error);
    return false;
  }
}

module.exports = { sendOTP };
