const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: process.env.SMTP_PORT || 587,
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS
  }
});

async function sendWelcomeEmail(email, name) {
  try {
    if (!process.env.SMTP_USER) {
      console.log(`Mock welcome email to ${email}`);
      return true;
    }

    await transporter.sendMail({
      from: process.env.FROM_EMAIL,
      to: email,
      subject: 'Welcome to Coupzii!',
      html: `<h1>Welcome ${name}!</h1><p>Thank you for joining Coupzii.</p>`
    });
    return true;
  } catch (error) {
    console.error('Email error:', error);
    return false;
  }
}

module.exports = { sendWelcomeEmail };
