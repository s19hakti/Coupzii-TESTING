// middleware/auth.js
const jwt = require('jsonwebtoken');
const { query } = require('../config/database');

// Verify JWT token
const authenticateToken = async (req, res, next) => {
  try {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
      return res.status(401).json({ error: 'Access token required' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // Attach user info to request
    req.user = decoded;
    next();
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Token expired' });
    }
    return res.status(403).json({ error: 'Invalid token' });
  }
};

// Verify user type
const requireUserType = (type) => {
  return (req, res, next) => {
    if (req.user.type !== type) {
      return res.status(403).json({ 
        error: `Access denied. This endpoint is for ${type}s only` 
      });
    }
    next();
  };
};

// Verify brand ownership
const verifyBrandOwnership = async (req, res, next) => {
  try {
    const brand_id = req.params.brand_id || req.body.brand_id;
    
    if (req.user.type !== 'brand') {
      return res.status(403).json({ error: 'Only brands can access this resource' });
    }

    if (req.user.user_id !== brand_id) {
      return res.status(403).json({ error: 'You can only access your own brand resources' });
    }

    next();
  } catch (error) {
    res.status(500).json({ error: 'Authorization check failed' });
  }
};

// Verify coupon ownership
const verifyCouponOwnership = async (req, res, next) => {
  try {
    const coupon_id = req.params.coupon_id || req.body.coupon_id;
    
    const result = await query(
      'SELECT * FROM coupons WHERE coupon_id = $1',
      [coupon_id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Coupon not found' });
    }

    const coupon = result.rows[0];

    // Check if user is the brand owner or coupon owner
    const isOwner = 
      (req.user.type === 'brand' && coupon.brand_id === req.user.user_id) ||
      (req.user.type === 'user' && coupon.owner_user_id === req.user.user_id);

    if (!isOwner) {
      return res.status(403).json({ error: 'You do not have permission to access this coupon' });
    }

    req.coupon = coupon;
    next();
  } catch (error) {
    res.status(500).json({ error: 'Authorization check failed' });
  }
};

module.exports = {
  authenticateToken,
  requireUserType,
  verifyBrandOwnership,
  verifyCouponOwnership
};
