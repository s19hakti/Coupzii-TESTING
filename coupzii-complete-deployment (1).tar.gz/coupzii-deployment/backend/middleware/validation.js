// middleware/validation.js
const Joi = require('joi');

// Registration validation schema
const registrationSchema = Joi.object({
  email: Joi.string().email().required(),
  phone: Joi.string().pattern(/^\+?[1-9]\d{1,14}$/).optional(),
  password: Joi.string().min(8).required(),
  full_name: Joi.string().min(2).optional(),
  brand_name: Joi.string().min(2).optional(),
  category: Joi.string().optional(),
  website: Joi.string().uri().optional(),
  description: Joi.string().optional()
});

// Login validation schema
const loginSchema = Joi.object({
  email: Joi.string().email().required(),
  password: Joi.string().required(),
  login_type: Joi.string().valid('user', 'brand').required()
});

// Coupon creation schema
const couponSchema = Joi.object({
  title: Joi.string().min(3).max(255).required(),
  coupon_code: Joi.string().min(3).max(100).required(),
  description: Joi.string().optional(),
  discount_type: Joi.string().valid('percentage', 'fixed_amount', 'bogo', 'free_shipping').required(),
  discount_value: Joi.number().min(0).required(),
  minimum_order_value: Joi.number().min(0).optional(),
  maximum_discount: Joi.number().min(0).optional(),
  category: Joi.string().optional(),
  valid_from: Joi.date().required(),
  valid_until: Joi.date().greater(Joi.ref('valid_from')).required(),
  total_stock: Joi.number().integer().min(1).optional(),
  max_uses_per_user: Joi.number().integer().min(1).default(1),
  terms_and_conditions: Joi.string().optional()
});

// Validation middleware factory
const validate = (schema) => {
  return (req, res, next) => {
    const { error, value } = schema.validate(req.body, { abortEarly: false });
    
    if (error) {
      const errors = error.details.map(detail => ({
        field: detail.path.join('.'),
        message: detail.message
      }));
      
      return res.status(400).json({ 
        error: 'Validation failed',
        details: errors
      });
    }
    
    req.validatedBody = value;
    next();
  };
};

module.exports = {
  validateRegistration: validate(registrationSchema),
  validateLogin: validate(loginSchema),
  validateCoupon: validate(couponSchema)
};
