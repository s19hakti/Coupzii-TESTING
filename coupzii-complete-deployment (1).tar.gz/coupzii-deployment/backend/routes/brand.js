// routes/brand.js - Brand management routes
const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { query } = require('../config/database');
const { authenticateToken, requireUserType } = require('../middleware/auth');
const { validateCoupon } = require('../middleware/validation');
const multer = require('multer');
const csv = require('csv-parser');
const xlsx = require('xlsx');
const { Readable } = require('stream');

const upload = multer({ storage: multer.memoryStorage() });

router.use(authenticateToken);
router.use(requireUserType('brand'));

// Create single coupon
router.post('/coupon/create', validateCoupon, async (req, res) => {
  try {
    const brand_id = req.user.user_id;
    const coupon_id = uuidv4();
    const { title, coupon_code, description, discount_type, discount_value,
            minimum_order_value, maximum_discount, category, valid_from,
            valid_until, total_stock, max_uses_per_user, terms_and_conditions } = req.validatedBody;

    await query(
      `INSERT INTO coupons (coupon_id, brand_id, source, coupon_code, title, description,
       discount_type, discount_value, minimum_order_value, maximum_discount, category,
       valid_from, valid_until, is_active, total_stock, remaining_stock, max_uses_per_user,
       terms_and_conditions, created_at)
       VALUES ($1, $2, 'brand', $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, true, $13, $13, $14, $15, NOW())`,
      [coupon_id, brand_id, coupon_code, title, description, discount_type, discount_value,
       minimum_order_value, maximum_discount, category, valid_from, valid_until,
       total_stock, max_uses_per_user, terms_and_conditions]
    );

    res.status(201).json({ message: 'Coupon created successfully', coupon_id });
  } catch (error) {
    console.error('Create coupon error:', error);
    res.status(500).json({ error: 'Failed to create coupon' });
  }
});

// Bulk upload coupons
router.post('/coupon/bulk-upload', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const brand_id = req.user.user_id;
    const coupons = [];
    const fileBuffer = req.file.buffer;

    // Parse Excel
    if (req.file.mimetype.includes('spreadsheet') || req.file.originalname.endsWith('.xlsx')) {
      const workbook = xlsx.read(fileBuffer);
      const sheetName = workbook.SheetNames[0];
      const data = xlsx.utils.sheet_to_json(workbook.Sheets[sheetName]);
      
      for (const row of data) {
        const coupon_id = uuidv4();
        await query(
          `INSERT INTO coupons (coupon_id, brand_id, source, coupon_code, title,
           discount_type, discount_value, minimum_order_value, valid_from, valid_until,
           is_active, created_at)
           VALUES ($1, $2, 'brand', $3, $4, $5, $6, $7, $8, $9, true, NOW())`,
          [coupon_id, brand_id, row.code, row.title, row.discount_type,
           row.discount_value, row.min_order || 0, row.valid_from, row.valid_until]
        );
        coupons.push(coupon_id);
      }
    }

    res.json({ message: `${coupons.length} coupons uploaded successfully`, coupons });
  } catch (error) {
    console.error('Bulk upload error:', error);
    res.status(500).json({ error: 'Failed to upload coupons' });
  }
});

// Get brand coupons
router.get('/coupons', async (req, res) => {
  try {
    const brand_id = req.user.user_id;
    const result = await query(
      `SELECT * FROM coupons WHERE brand_id = $1 ORDER BY created_at DESC`,
      [brand_id]
    );
    res.json({ coupons: result.rows });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch coupons' });
  }
});

// Get analytics
router.get('/analytics', async (req, res) => {
  try {
    const brand_id = req.user.user_id;
    const { start_date, end_date } = req.query;

    const result = await query(
      `SELECT 
        COUNT(*) as total_coupons,
        COUNT(*) FILTER (WHERE is_active = true) as active_coupons,
        SUM(total_redemptions) as total_redemptions,
        SUM(total_views) as total_views
       FROM coupons WHERE brand_id = $1`,
      [brand_id]
    );

    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch analytics' });
  }
});

module.exports = router;
