// routes/user.js
const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { query, transaction } = require('../config/database');
const { cache } = require('../config/redis');
const { authenticateToken, requireUserType } = require('../middleware/auth');
const { uploadToS3 } = require('../services/storage');
const multer = require('multer');

const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB
});

// All routes require authentication
router.use(authenticateToken);
router.use(requireUserType('user'));

// GET /api/user/wallet - Get user's wallet coupons
router.get('/wallet', async (req, res) => {
  try {
    const { source, status } = req.query;
    const user_id = req.user.user_id;

    let queryText = `
      SELECT 
        uw.*,
        c.*,
        b.brand_name,
        b.logo_url as brand_logo
      FROM user_wallet uw
      JOIN coupons c ON uw.coupon_id = c.coupon_id
      LEFT JOIN brands b ON c.brand_id = b.brand_id
      WHERE uw.user_id = $1
    `;

    const params = [user_id];
    let paramCount = 1;

    if (source) {
      paramCount++;
      queryText += ` AND uw.source = $${paramCount}`;
      params.push(source);
    }

    if (status === 'active') {
      queryText += ` AND uw.is_used = false AND c.valid_until > NOW()`;
    } else if (status === 'used') {
      queryText += ` AND uw.is_used = true`;
    } else if (status === 'expired') {
      queryText += ` AND c.valid_until < NOW()`;
    }

    queryText += ` ORDER BY uw.added_at DESC`;

    // Try cache first
    const cacheKey = `wallet:${user_id}:${source || 'all'}:${status || 'all'}`;
    const cached = await cache.get(cacheKey);
    
    if (cached) {
      return res.json({ coupons: cached, source: 'cache' });
    }

    const result = await query(queryText, params);
    
    // Cache for 5 minutes
    await cache.set(cacheKey, result.rows, 300);

    res.json({ 
      coupons: result.rows,
      total: result.rows.length 
    });
  } catch (error) {
    console.error('Get wallet error:', error);
    res.status(500).json({ error: 'Failed to fetch wallet' });
  }
});

// POST /api/user/wallet/add - Add coupon to wallet
router.post('/wallet/add', upload.single('screenshot'), async (req, res) => {
  try {
    const user_id = req.user.user_id;
    const { coupon_code, brand, discount, manual_entry } = req.body;

    let screenshot_url = null;
    let ocr_data = null;

    // Upload screenshot if provided
    if (req.file) {
      screenshot_url = await uploadToS3(req.file, 'coupons');
      // TODO: Implement OCR to extract coupon data
      // ocr_data = await extractCouponData(screenshot_url);
    }

    // If manual entry, create or find coupon
    let coupon_id;
    
    if (manual_entry) {
      // Check if coupon already exists
      const existingCoupon = await query(
        'SELECT coupon_id FROM coupons WHERE coupon_code = $1',
        [coupon_code]
      );

      if (existingCoupon.rows.length > 0) {
        coupon_id = existingCoupon.rows[0].coupon_id;
      } else {
        // Create new coupon from manual entry
        coupon_id = uuidv4();
        await query(
          `INSERT INTO coupons (
            coupon_id, owner_user_id, source, coupon_code, title, 
            discount_type, discount_value, is_active, created_at
          ) VALUES ($1, $2, 'user_upload', $3, $4, 'percentage', $5, true, NOW())`,
          [coupon_id, user_id, coupon_code, brand || 'Unknown Brand', parseFloat(discount) || 0]
        );
      }
    } else {
      // Find coupon by code
      const result = await query(
        'SELECT coupon_id FROM coupons WHERE coupon_code = $1',
        [coupon_code]
      );

      if (result.rows.length === 0) {
        return res.status(404).json({ error: 'Coupon not found' });
      }

      coupon_id = result.rows[0].coupon_id;
    }

    // Add to wallet
    const wallet_id = uuidv4();
    await query(
      `INSERT INTO user_wallet (
        wallet_id, user_id, coupon_id, source, screenshot_url, 
        ocr_data, added_at
      ) VALUES ($1, $2, $3, 'synced', $4, $5, NOW())`,
      [wallet_id, user_id, coupon_id, screenshot_url, JSON.stringify(ocr_data)]
    );

    // Clear cache
    await cache.delPattern(`wallet:${user_id}:*`);

    res.status(201).json({ 
      message: 'Coupon added to wallet successfully',
      wallet_id,
      coupon_id
    });
  } catch (error) {
    console.error('Add to wallet error:', error);
    res.status(500).json({ error: 'Failed to add coupon to wallet' });
  }
});

// GET /api/user/wallet/stats - Get wallet statistics
router.get('/wallet/stats', async (req, res) => {
  try {
    const user_id = req.user.user_id;

    const stats = await query(`
      SELECT 
        COUNT(*) FILTER (WHERE uw.is_used = false AND c.valid_until > NOW()) as active_coupons,
        COUNT(*) FILTER (WHERE uw.is_used = true) as used_coupons,
        COUNT(*) FILTER (WHERE c.valid_until < NOW() AND c.valid_until > NOW() - INTERVAL '7 days') as expiring_soon,
        COALESCE(SUM(CASE 
          WHEN c.discount_type = 'percentage' AND uw.is_used = true 
          THEN (uw.purchase_price * c.discount_value / 100)
          WHEN c.discount_type = 'fixed_amount' AND uw.is_used = true
          THEN c.discount_value
          ELSE 0
        END), 0) as total_savings
      FROM user_wallet uw
      JOIN coupons c ON uw.coupon_id = c.coupon_id
      WHERE uw.user_id = $1
    `, [user_id]);

    res.json(stats.rows[0]);
  } catch (error) {
    console.error('Get wallet stats error:', error);
    res.status(500).json({ error: 'Failed to fetch statistics' });
  }
});

// GET /api/user/marketplace - Get marketplace listings
router.get('/marketplace', async (req, res) => {
  try {
    const { category, sort = 'created_at', order = 'DESC', limit = 20, offset = 0 } = req.query;

    let queryText = `
      SELECT 
        ml.*,
        c.*,
        u.full_name as seller_name,
        b.brand_name,
        b.logo_url as brand_logo
      FROM marketplace_listings ml
      JOIN coupons c ON ml.coupon_id = c.coupon_id
      JOIN users u ON ml.seller_user_id = u.user_id
      LEFT JOIN brands b ON c.brand_id = b.brand_id
      WHERE ml.is_active = true 
        AND c.valid_until > NOW()
        AND ml.seller_user_id != $1
    `;

    const params = [req.user.user_id];
    let paramCount = 1;

    if (category) {
      paramCount++;
      queryText += ` AND c.category = $${paramCount}`;
      params.push(category);
    }

    const validSortFields = ['created_at', 'listing_price', 'discount_value'];
    const sortField = validSortFields.includes(sort) ? sort : 'created_at';
    
    queryText += ` ORDER BY ${sortField} ${order === 'ASC' ? 'ASC' : 'DESC'}`;
    queryText += ` LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}`;
    params.push(limit, offset);

    // Try cache
    const cacheKey = `marketplace:${category || 'all'}:${sort}:${order}:${limit}:${offset}`;
    const cached = await cache.get(cacheKey);
    
    if (cached) {
      return res.json({ listings: cached, source: 'cache' });
    }

    const result = await query(queryText, params);
    
    // Cache for 2 minutes
    await cache.set(cacheKey, result.rows, 120);

    res.json({ listings: result.rows, total: result.rows.length });
  } catch (error) {
    console.error('Get marketplace error:', error);
    res.status(500).json({ error: 'Failed to fetch marketplace listings' });
  }
});

// POST /api/user/marketplace/list - List a coupon for sale
router.post('/marketplace/list', async (req, res) => {
  try {
    const { coupon_id, listing_price, is_exchangeable } = req.body;
    const user_id = req.user.user_id;

    // Verify user owns the coupon
    const walletCheck = await query(
      'SELECT * FROM user_wallet WHERE user_id = $1 AND coupon_id = $2 AND is_used = false',
      [user_id, coupon_id]
    );

    if (walletCheck.rows.length === 0) {
      return res.status(403).json({ error: 'You do not own this coupon or it has been used' });
    }

    // Check if already listed
    const existingListing = await query(
      'SELECT * FROM marketplace_listings WHERE coupon_id = $1 AND is_active = true',
      [coupon_id]
    );

    if (existingListing.rows.length > 0) {
      return res.status(400).json({ error: 'Coupon is already listed' });
    }

    // Create listing
    const listing_id = uuidv4();
    await query(
      `INSERT INTO marketplace_listings (
        listing_id, seller_user_id, coupon_id, listing_price, 
        is_active, is_exchangeable, created_at
      ) VALUES ($1, $2, $3, $4, true, $5, NOW())`,
      [listing_id, user_id, coupon_id, listing_price, is_exchangeable || false]
    );

    // Clear marketplace cache
    await cache.delPattern('marketplace:*');

    res.status(201).json({ 
      message: 'Coupon listed successfully',
      listing_id 
    });
  } catch (error) {
    console.error('List coupon error:', error);
    res.status(500).json({ error: 'Failed to list coupon' });
  }
});

// GET /api/user/profile - Get user profile
router.get('/profile', async (req, res) => {
  try {
    const result = await query(
      'SELECT user_id, email, phone, full_name, profile_image, created_at FROM users WHERE user_id = $1',
      [req.user.user_id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({ user: result.rows[0] });
  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({ error: 'Failed to fetch profile' });
  }
});

// PUT /api/user/profile - Update user profile
router.put('/profile', upload.single('profile_image'), async (req, res) => {
  try {
    const { full_name, phone } = req.body;
    const user_id = req.user.user_id;

    let profile_image = null;
    if (req.file) {
      profile_image = await uploadToS3(req.file, 'profiles');
    }

    const updates = [];
    const params = [];
    let paramCount = 0;

    if (full_name) {
      paramCount++;
      updates.push(`full_name = $${paramCount}`);
      params.push(full_name);
    }

    if (phone) {
      paramCount++;
      updates.push(`phone = $${paramCount}`);
      params.push(phone);
    }

    if (profile_image) {
      paramCount++;
      updates.push(`profile_image = $${paramCount}`);
      params.push(profile_image);
    }

    if (updates.length === 0) {
      return res.status(400).json({ error: 'No fields to update' });
    }

    paramCount++;
    params.push(user_id);

    await query(
      `UPDATE users SET ${updates.join(', ')}, updated_at = NOW() WHERE user_id = $${paramCount}`,
      params
    );

    res.json({ message: 'Profile updated successfully' });
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({ error: 'Failed to update profile' });
  }
});

module.exports = router;
