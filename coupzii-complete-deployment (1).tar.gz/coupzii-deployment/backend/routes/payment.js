const express = require('express');
const router = express.Router();
const Razorpay = require('razorpay');
const crypto = require('crypto');
const { authenticateToken } = require('../middleware/auth');

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET
});

router.post('/create-order', authenticateToken, async (req, res) => {
  try {
    const { amount, coupon_id } = req.body;
    const options = {
      amount: amount * 100,
      currency: 'INR',
      receipt: `coupon_${coupon_id}_${Date.now()}`
    };
    const order = await razorpay.orders.create(options);
    res.json({ order });
  } catch (error) {
    res.status(500).json({ error: 'Payment creation failed' });
  }
});

router.post('/verify', authenticateToken, async (req, res) => {
  try {
    const { order_id, payment_id, signature } = req.body;
    const body = order_id + '|' + payment_id;
    const expectedSignature = crypto.createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
      .update(body).digest('hex');
    
    if (expectedSignature === signature) {
      res.json({ success: true, message: 'Payment verified' });
    } else {
      res.status(400).json({ error: 'Invalid signature' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Verification failed' });
  }
});

module.exports = router;
