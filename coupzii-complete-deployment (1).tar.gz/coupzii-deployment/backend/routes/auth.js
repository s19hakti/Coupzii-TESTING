// routes/auth.js
const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { query, transaction } = require('../config/database');
const { cache } = require('../config/redis');
const { sendOTP, verifyOTP } = require('../services/sms');
const { sendWelcomeEmail } = require('../services/email');
const { validateRegistration, validateLogin } = require('../middleware/validation');

// Generate JWT tokens
const generateTokens = (user) => {
  const accessToken = jwt.sign(
    { 
      user_id: user.user_id || user.brand_id,
      email: user.email,
      type: user.brand_id ? 'brand' : 'user'
    },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN }
  );

  const refreshToken = jwt.sign(
    { user_id: user.user_id || user.brand_id },
    process.env.JWT_REFRESH_SECRET,
    { expiresIn: process.env.JWT_REFRESH_EXPIRES_IN }
  );

  return { accessToken, refreshToken };
};

// POST /api/auth/register/user
router.post('/register/user', validateRegistration, async (req, res) => {
  try {
    const { email, phone, password, full_name } = req.body;

    // Check if user already exists
    const existingUser = await query(
      'SELECT * FROM users WHERE email = $1 OR phone = $2',
      [email, phone]
    );

    if (existingUser.rows.length > 0) {
      return res.status(400).json({ 
        error: 'User already exists with this email or phone' 
      });
    }

    // Hash password
    const password_hash = await bcrypt.hash(password, 10);

    // Create user
    const user_id = uuidv4();
    const result = await query(
      `INSERT INTO users (user_id, email, phone, password_hash, full_name, created_at)
       VALUES ($1, $2, $3, $4, $5, NOW())
       RETURNING user_id, email, phone, full_name, created_at`,
      [user_id, email, phone, password_hash, full_name]
    );

    const newUser = result.rows[0];

    // Generate OTP for verification
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    await cache.set(`otp:${user_id}`, otp, 600); // 10 minutes

    // Send OTP
    if (phone) {
      await sendOTP(phone, otp);
    }

    // Send welcome email
    await sendWelcomeEmail(email, full_name);

    res.status(201).json({
      message: 'User registered successfully. Please verify your phone.',
      user: {
        user_id: newUser.user_id,
        email: newUser.email,
        phone: newUser.phone,
        full_name: newUser.full_name
      },
      verification_required: true
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Registration failed' });
  }
});

// POST /api/auth/register/brand
router.post('/register/brand', validateRegistration, async (req, res) => {
  try {
    const { brand_name, email, password, category, website, description } = req.body;

    // Check if brand exists
    const existingBrand = await query(
      'SELECT * FROM brands WHERE email = $1',
      [email]
    );

    if (existingBrand.rows.length > 0) {
      return res.status(400).json({ 
        error: 'Brand already registered with this email' 
      });
    }

    // Hash password
    const password_hash = await bcrypt.hash(password, 10);

    // Create brand
    const brand_id = uuidv4();
    const result = await query(
      `INSERT INTO brands (brand_id, brand_name, email, password_hash, category, website, description, created_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())
       RETURNING brand_id, brand_name, email, category, created_at`,
      [brand_id, brand_name, email, password_hash, category, website, description]
    );

    const newBrand = result.rows[0];

    // Send welcome email
    await sendWelcomeEmail(email, brand_name);

    // Generate tokens
    const tokens = generateTokens(newBrand);

    res.status(201).json({
      message: 'Brand registered successfully',
      brand: {
        brand_id: newBrand.brand_id,
        brand_name: newBrand.brand_name,
        email: newBrand.email,
        category: newBrand.category
      },
      ...tokens
    });
  } catch (error) {
    console.error('Brand registration error:', error);
    res.status(500).json({ error: 'Registration failed' });
  }
});

// POST /api/auth/login
router.post('/login', validateLogin, async (req, res) => {
  try {
    const { email, password, login_type } = req.body;

    let user;
    let tableName = login_type === 'brand' ? 'brands' : 'users';
    let idField = login_type === 'brand' ? 'brand_id' : 'user_id';

    // Get user/brand from database
    const result = await query(
      `SELECT * FROM ${tableName} WHERE email = $1`,
      [email]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    user = result.rows[0];

    // Verify password
    const isValidPassword = await bcrypt.compare(password, user.password_hash);
    if (!isValidPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Update last login
    await query(
      `UPDATE ${tableName} SET last_login = NOW() WHERE ${idField} = $1`,
      [user[idField]]
    );

    // Generate tokens
    const tokens = generateTokens(user);

    // Remove sensitive data
    delete user.password_hash;

    res.json({
      message: 'Login successful',
      user,
      ...tokens,
      type: login_type
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Login failed' });
  }
});

// POST /api/auth/verify-otp
router.post('/verify-otp', async (req, res) => {
  try {
    const { user_id, otp } = req.body;

    // Get OTP from cache
    const cachedOTP = await cache.get(`otp:${user_id}`);

    if (!cachedOTP) {
      return res.status(400).json({ error: 'OTP expired or invalid' });
    }

    if (cachedOTP !== otp) {
      return res.status(400).json({ error: 'Invalid OTP' });
    }

    // Mark user as verified
    await query(
      'UPDATE users SET is_verified = true WHERE user_id = $1',
      [user_id]
    );

    // Delete OTP from cache
    await cache.del(`otp:${user_id}`);

    // Get updated user
    const result = await query(
      'SELECT user_id, email, phone, full_name, is_verified FROM users WHERE user_id = $1',
      [user_id]
    );

    const user = result.rows[0];

    // Generate tokens
    const tokens = generateTokens(user);

    res.json({
      message: 'Phone verified successfully',
      user,
      ...tokens
    });
  } catch (error) {
    console.error('OTP verification error:', error);
    res.status(500).json({ error: 'Verification failed' });
  }
});

// POST /api/auth/refresh-token
router.post('/refresh-token', async (req, res) => {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      return res.status(401).json({ error: 'Refresh token required' });
    }

    // Verify refresh token
    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);

    // Get user
    const result = await query(
      'SELECT * FROM users WHERE user_id = $1',
      [decoded.user_id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    const user = result.rows[0];
    const tokens = generateTokens(user);

    res.json(tokens);
  } catch (error) {
    console.error('Token refresh error:', error);
    res.status(401).json({ error: 'Invalid refresh token' });
  }
});

// POST /api/auth/forgot-password
router.post('/forgot-password', async (req, res) => {
  try {
    const { email } = req.body;

    // Check if user exists
    const result = await query(
      'SELECT user_id, email, full_name FROM users WHERE email = $1',
      [email]
    );

    if (result.rows.length === 0) {
      // Don't reveal if user exists
      return res.json({ message: 'If the email exists, a reset link has been sent' });
    }

    const user = result.rows[0];

    // Generate reset token
    const resetToken = jwt.sign(
      { user_id: user.user_id },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );

    // Store reset token in cache
    await cache.set(`reset:${user.user_id}`, resetToken, 3600);

    // Send reset email (implement this in email service)
    // await sendPasswordResetEmail(user.email, resetToken);

    res.json({ message: 'If the email exists, a reset link has been sent' });
  } catch (error) {
    console.error('Forgot password error:', error);
    res.status(500).json({ error: 'Failed to process request' });
  }
});

// POST /api/auth/reset-password
router.post('/reset-password', async (req, res) => {
  try {
    const { token, newPassword } = req.body;

    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Check if token exists in cache
    const cachedToken = await cache.get(`reset:${decoded.user_id}`);
    if (!cachedToken || cachedToken !== token) {
      return res.status(400).json({ error: 'Invalid or expired reset token' });
    }

    // Hash new password
    const password_hash = await bcrypt.hash(newPassword, 10);

    // Update password
    await query(
      'UPDATE users SET password_hash = $1 WHERE user_id = $2',
      [password_hash, decoded.user_id]
    );

    // Delete reset token
    await cache.del(`reset:${decoded.user_id}`);

    res.json({ message: 'Password reset successfully' });
  } catch (error) {
    console.error('Reset password error:', error);
    res.status(500).json({ error: 'Failed to reset password' });
  }
});

module.exports = router;
