const express = require('express');
const router = express.Router();
const { query } = require('../config/database');

router.get('/listings', async (req, res) => {
  try {
    const result = await query('SELECT * FROM marketplace_listings WHERE is_active = true LIMIT 50');
    res.json({ listings: result.rows });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch listings' });
  }
});

module.exports = router;
