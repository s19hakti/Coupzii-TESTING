const express = require('express');
const router = express.Router();
const { query } = require('../config/database');

router.get('/:coupon_id', async (req, res) => {
  try {
    const result = await query('SELECT * FROM coupons WHERE coupon_id = $1', [req.params.coupon_id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Coupon not found' });
    res.json({ coupon: result.rows[0] });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch coupon' });
  }
});

module.exports = router;
